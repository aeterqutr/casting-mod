﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using CameraMod;
using Fusion;
using GorillaExtensions;
using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using Liv.Lck;
using Meta.WitAi;
using Photon.Pun;
using Photon.Realtime;
using Photon.Voice;
using TMPro;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.InputSystem;
using UnityEngine.ProBuilder;
using UnityEngine.TextCore.Text;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit;
using Valve.Newtonsoft.Json;
using Valve.Newtonsoft.Json.Bson;
using Valve.VR.InteractionSystem;
using static QRCoder.PayloadGenerator;
using static SteamVR_Utils.Event;
using static TMPro.SpriteAssetUtilities.TexturePacker_JsonArray;
using Math = System.Math;
using Player = Photon.Realtime.Player;

namespace CameraMod
{
    public class GorillaData
    {
        public Color Color;
        public string UserName;
        public string UserId;
        public bool Infected;
        public Transform BodyTransform;
        public Transform HeadTransform;
    }
    // Token: 0x02000002 RID: 2
    [BepInPlugin("com.qutr.CameraMod", "CameraMod", "1.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        bool scoreboardon;
        private Texture2D scoreheadertexture;
        bool roomjoiner;
        bool namechanger;
        bool colorchanger;
        Rect roomJoiner = new Rect(0f, 0f, 200f, 100f);
        Rect nameChanger = new Rect(0f, 0f, 200f, 100f);
        Rect colorChanger = new Rect(0f, 0f, 200f, 100f);

        Rect scoreboardrect = new Rect(100f, 100f, 250f, 100f);
        string team1 = "Left", team2 = "Right";
        int team1p, team2p;

        public int width = 512;
        public int height = 512;
        public int cornerRadius = 50;
        public Color boxColor = Color.black;

        float taggingdistance;
        private static Dictionary<VRRig, GameObject> FPSnametags = new Dictionary<VRRig, GameObject> { };
        bool fpsnametags;
        private static Dictionary<VRRig, GameObject> Nametags = new Dictionary<VRRig, GameObject> { };
        bool nametags;

        bool miconoroff = true;
        bool taggerdistance;
        float[] geussedpreds;
        float normalpreds;

        string roomjoinertext = "";

        string isonsteam;
        Texture2D meta;
        Texture2D steam;
        Camera CastingCamera;
        bool predguesserleaderboard = true, predguesser;
        Camera MinimapCamera;
        VRRig CastedPlayer;

        Texture2D mic_on;
        Texture2D mic_off;
        Texture2D box_background;
        Texture2D box_texture;
        private bool SettingsWindow = false;

        TMP_FontAsset GorillaTagFont;

        bool showgui = true;
        int preds;
        string spoofedfps;

        bool cameralookatplayer;
        bool leaderboard = true;
        string CameraParent = "Head";
        float camoffsetz = 2f, camoffsetx = 0f, camoffsety = 0.5f;
        float smoothening = 0.4f, fov = 100f;

        private bool showCamSettings = false;
        private bool showOtherGUIs = false;
        private bool showMiscMods = false;
        private bool showModCheckers = false;

        private Rect camSettingsRect = new Rect(350, 30, 250, 400);
        private Rect otherGUIsRect = new Rect(350, 450, 300, 300);
        private Rect miscModsRect = new Rect(700, 30, 300, 350);
        private Rect modCheckersRect = new Rect(700, 400, 300, 250);
        private VRRig[] plrs;
        bool showplatform;
        bool fpsleaderboard;
        VRRig closestFected;

        void Start()
        {
            GameObject.Find("Shoulder Camera").SetActive(false);
            CastingCamera = new GameObject().AddComponent<Camera>();
            CastingCamera.cameraType = CameraType.Preview;
            CastingCamera.depth = 2f;
            CastedPlayer = GorillaTagger.Instance.offlineVRRig;
            CreateFont();
            CreateTextures();
            InitializeScoreboard();
            RetrieveAssets();
            StartCamListener();
        }


        private void GetDistToFected(ref float output)
        {
            float num = float.MaxValue;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != null && vrrig.mainSkin.material.name.Contains("fected"))
                {
                    float num2 = Vector3.Distance(CastedPlayer.transform.position, vrrig.transform.position);
                    if (num2 < num)
                    {
                        num = num2;
                        closestFected = vrrig;
                    }
                }
            }
            output = num;
        }

        void LateUpdate()
        {
            DrawLeaderboard();
            if (movewithwasd) MoveCamWithWasd();
        }

        AssetBundle _assetBundle;
        private Font _defaultFont;
        private TMP_FontAsset _defaultFontAsset;
        private Font _gtagFont;
        private TMP_FontAsset _gtagFontAsset;
        private Font _pixelFont;
        private TMP_FontAsset _pixelFontAsset;
        private Font _gothamFont;
        private TMP_FontAsset _gothamFontAsset;
        private Font _designerFont;
        private TMP_FontAsset _designerFontAsset;
        private GameObject _playerCardObject;
        private GameObject _killFeedCardObject;
        private GameObject _playerDistanceCardObject;
        private GameObject _leaderboardCanvasObj;
        private Canvas _leaderboardCanvas;
        private GameObject _scoreboardCanvasObj;
        private Canvas _scoreboardCanvas;
        private GameObject _mainScoreboardObj;
        private GameObject _cherryScoreboardObj;
        private GameObject _playerScoreboardObj;
        private TMP_Text _team1NameText;
        private TMP_Text _team2NameText;
        private TMP_Text _team1ScoreText;
        private TMP_Text _team2ScoreText;
        private TMP_Text _currentTimerText;
        private TMP_Text _oldTimerText;
        private Vector2 _scorePos = new Vector3(0f, 0f);
        private GameObject _killFeedCanvasObj;
        private Canvas _killFeedCanvas;
        private GameObject _playerDistanceCard;
        private GameObject _playerDistanceCanvasObj;
        private Canvas _playerDistanceCanvas;
        private GameObject _nameTag;
        private GameObject _cgtScoreboardObj;

        private void RetrieveAssets()
        {
            _assetBundle = AssetBundle.LoadFromStreamAsync(Assembly.GetExecutingAssembly().GetManifestResourceStream("GUISTYLETEMP.Assets.scmab2")).assetBundle;
            if (_assetBundle != null)
            {
                Debug.Log("Loaded CastingMod AssetBundle!");
                this._leaderboardCanvasObj = new GameObject("LeaderboardCanvas");
                this._leaderboardCanvas = this._leaderboardCanvasObj.AddComponent<Canvas>();
                this._leaderboardCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                this._leaderboardCanvasObj.AddComponent<CanvasScaler>();
                this._leaderboardCanvasObj.AddComponent<GraphicRaycaster>();

                // Find the PlayerCard(Clone) - this assumes it's a child of the canvas
                GameObject playerCardTransform = _leaderboardCanvasObj.Find("PlayerCard(Clone)");
                if (playerCardTransform != null)
                {
                    GameObject behindTransform = playerCardTransform.Find("Behind");
                    if (behindTransform != null)
                    {
                        GameObject playerBGTransform = behindTransform.Find("PlayerBG");
                        if (playerBGTransform != null)
                        {
                            playerBGTransform.gameObject.SetActive(false);
                        }
                        else
                        {
                            Debug.LogWarning("PlayerBG not found under Behind");
                        }
                    }
                    else
                    {
                        Debug.LogWarning("Behind not found under PlayerCard(Clone)");
                    }
                }
                else
                {
                    Debug.LogWarning("PlayerCard(Clone) not found under LeaderboardCanvas");
                }
                this._scoreboardCanvasObj = new GameObject("ScoreboardCanvas");
                this._scoreboardCanvas = this._scoreboardCanvasObj.AddComponent<Canvas>();
                this._scoreboardCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                this._scoreboardCanvasObj.AddComponent<CanvasScaler>();
                this._scoreboardCanvasObj.AddComponent<GraphicRaycaster>();
                this._mainScoreboardObj = UnityEngine.Object.Instantiate<GameObject>(this._assetBundle.LoadAsset<GameObject>("Scoreboard"), this._scoreboardCanvas.transform);
                this._cherryScoreboardObj = UnityEngine.Object.Instantiate<GameObject>(this._assetBundle.LoadAsset<GameObject>("SakuraaScoreboard"), this._scoreboardCanvas.transform);
                this._playerScoreboardObj = UnityEngine.Object.Instantiate<GameObject>(this._assetBundle.LoadAsset<GameObject>("PlayerScoreboard"), this._scoreboardCanvas.transform);
                this._cgtScoreboardObj = UnityEngine.Object.Instantiate<GameObject>(this._assetBundle.LoadAsset<GameObject>("CgtScoreboard"), this._scoreboardCanvas.transform);
                this._scorePos = new Vector2((float)Screen.width / 2f, (float)(Screen.height - 135));
                this._playerScoreboardObj.transform.localScale *= 1.2f;
                this._playerScoreboardObj.transform.GetChild(0).position = new Vector3(585f, this._playerScoreboardObj.transform.GetChild(0).position.y);
                this._playerScoreboardObj.transform.GetChild(1).position = new Vector3((float)(Screen.width - 585), this._playerScoreboardObj.transform.GetChild(0).position.y);
                this._team1NameText = this._mainScoreboardObj.transform.GetChild(0).Find("Team1Text").GetComponent<TextMeshProUGUI>();
                this._team2NameText = this._mainScoreboardObj.transform.GetChild(0).Find("Team2Text").GetComponent<TextMeshProUGUI>();
                this._team1ScoreText = this._mainScoreboardObj.transform.GetChild(0).Find("Score1").GetComponent<TextMeshProUGUI>();
                this._team2ScoreText = this._mainScoreboardObj.transform.GetChild(0).Find("Score2").GetComponent<TextMeshProUGUI>();
                this._currentTimerText = this._mainScoreboardObj.transform.GetChild(0).Find("Timer").GetComponent<TextMeshProUGUI>();
                this._oldTimerText = this._mainScoreboardObj.transform.GetChild(0).Find("Timer (1)").GetComponent<TextMeshProUGUI>();
                this._mainScoreboardObj.SetActive(false);
                this._cherryScoreboardObj.SetActive(false);
                this._playerScoreboardObj.SetActive(false);
                this._cgtScoreboardObj.SetActive(false);
                this._killFeedCanvasObj = new GameObject("KillFeedCanvas");
                this._killFeedCanvas = this._killFeedCanvasObj.AddComponent<Canvas>();
                this._killFeedCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                this._killFeedCanvasObj.AddComponent<CanvasScaler>();
                this._killFeedCanvasObj.AddComponent<GraphicRaycaster>();
                this._playerDistanceCanvasObj = new GameObject("PlayerDistanceCanvas");
                this._playerDistanceCanvas = this._playerDistanceCanvasObj.AddComponent<Canvas>();
                this._playerDistanceCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                this._playerDistanceCanvasObj.AddComponent<CanvasScaler>();
                this._playerDistanceCanvasObj.AddComponent<GraphicRaycaster>();
                this._playerDistanceCardObject = this._assetBundle.LoadAsset<GameObject>("PlayerDistanceCard");
                this._playerCardObject = this._assetBundle.LoadAsset<GameObject>("PlayerCard");
                this._killFeedCardObject = this._assetBundle.LoadAsset<GameObject>("KillFeedCard");
                this._defaultFont = this._assetBundle.LoadAsset<Font>("font");
                this._defaultFontAsset = this._assetBundle.LoadAsset<TMP_FontAsset>("font SDF");
                this._gtagFont = this._assetBundle.LoadAsset<Font>("gtag_font");
                this._gtagFontAsset = this._assetBundle.LoadAsset<TMP_FontAsset>("gtag_font SDF");
                this._pixelFont = this._assetBundle.LoadAsset<Font>("Pixel Font");
                this._pixelFontAsset = this._assetBundle.LoadAsset<TMP_FontAsset>("pixel Font SDF");
                this._designerFont = this._assetBundle.LoadAsset<Font>("Designer");
                this._designerFontAsset = this._assetBundle.LoadAsset<TMP_FontAsset>("Designer SDF");
                this._gothamFont = this._assetBundle.LoadAsset<Font>("Gotham Ultra");
                this._gothamFontAsset = this._assetBundle.LoadAsset<TMP_FontAsset>("Gotham Ultra SDF");
                this._nameTag = this._assetBundle.LoadAsset<GameObject>("NameTagPlate");
                Debug.Log("Loaded CastingMod Assets! :3 >.<");
                return;
            }
            Debug.LogError("Failed to load CastingMod AssetBundle! > ~ <");
        }

        void OnDisable()
        {
            foreach (var tag in FPSnametags.Values)
                if (tag != null) Destroy(tag);
            foreach (var tag in Nametags.Values)
                if (tag != null) Destroy(tag);
            FPSnametags.Clear();
            Nametags.Clear();
        }
        bool movewithwasd = false;
        void CreateTextures()
        {
            meta = LoadTexture("meta.png", new Vector2Int(128, 32));
            steam = LoadTexture("steam.png", new Vector2Int(128, 32));

            mic_on = LoadTexture("mic.on_transparent.png", new Vector2Int(900, 1000));
            mic_off = LoadTexture("mic.off_transparent.png", new Vector2Int(900, 1000));

            box_background = LoadTexture("parrallelagram.transparent.png", new Vector2Int(900, 1000));
            box_texture = LoadTexture("box.background.png", new Vector2Int(900, 1000));
            
        }
        TMP_FontAsset _RuggedRide;
        TMP_FontAsset _RushDriver;
        TMP_FontAsset _Amatuer;

        void MoveCamWithWasd()
        {
            if (Keyboard.current.sKey.isPressed)
            {
                this.camoffsetz += Time.deltaTime * 2f;
            }
            if (Keyboard.current.wKey.isPressed)
            {
                this.camoffsetz -= Time.deltaTime * 2f;
            }
            if (Keyboard.current.dKey.isPressed)
            {
                this.camoffsetx += Time.deltaTime * 2f;
            }
            if (Keyboard.current.aKey.isPressed)
            {
                this.camoffsetx -= Time.deltaTime * 2f;
            }
            if (Keyboard.current.eKey.isPressed)
            {
                this.camoffsety += Time.deltaTime * 2f;
            }
            if (Keyboard.current.qKey.isPressed)
            {
                this.camoffsety -= Time.deltaTime * 2f;
            }
        }

        void CreateFont()
        {
            if (GorillaTagFont == null)
                GorillaTagFont = GameObject.Find("motdtext").GetComponent<TextMeshPro>().font;

            if (_RuggedRide == null)
            {
                _RuggedRide = Create("GUISTYLETEMP.Rugged Ride.ttf");
            }
            if (_RushDriver == null)
            {
                _RushDriver = Create("GUISTYLETEMP.RushDriver-Italic.otf");
            }
            if (_Amatuer == null)
            {
                _Amatuer = Create("GUISTYLETEMP.Amateur Dirty.ttf");
            }
        }

        bool _showDistanceCard;
        bool _autoPilot;
        GorillaData _currentSpecGorilla;

        void TagManager(int i)
        {
            GUILayout.Space(15f);
            GUILayout.BeginVertical();
            int num = 1;
            foreach (Player plr in PhotonNetwork.PlayerListOthers)
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label(num + ". " + plr.NickName);
                if (GUILayout.Button("Tag Player")) TagPlayer(plr);
                GUILayout.EndHorizontal();
                num++;
            }
        }

        private void DrawDistanceCard()
        {
            if (CastedPlayer == null)
                return;

            if (_playerDistanceCard == null)
            {
                _playerDistanceCard = Instantiate(_playerDistanceCardObject, _playerDistanceCanvasObj.transform);
                _playerDistanceCard.transform.localScale = Vector3.one * 1.7f;
                _playerDistanceCard.transform.position = new Vector3(Screen.width / 2f, 0f, 0f);
                return;
            }

            if (CastedPlayer.lavaParticleSystem.isPlaying)
            {
                _playerDistanceCard.SetActive(false);
                return;
            }

            TMP_Text distanceText = _playerDistanceCard.transform.Find("DistanceCounterText")?.GetComponent<TMP_Text>();
            if (distanceText == null)
                return;

            distanceText.font = _defaultFontAsset;

            if (taggingdistance < float.PositiveInfinity)
            {
                distanceText.text = $"Lava Distance: {Mathf.RoundToInt(taggingdistance)} ft";
                _playerDistanceCard.SetActive(true);
            }
            else
            {
                _playerDistanceCard.SetActive(false);
            }
        }
        public TMP_FontAsset Create(string resourcePath)
        {
            Assembly executingAssembly = Assembly.GetExecutingAssembly();

            using (Stream stream = executingAssembly.GetManifestResourceStream(resourcePath))
            {
                if (stream == null)
                {
                    Debug.LogError($"Could not find font resource: {resourcePath}");
                    return null;
                }
                byte[] buffer = new byte[stream.Length];
                stream.Read(buffer, 0, buffer.Length);
                string tempFontPath = Path.Combine(Application.temporaryCachePath, Path.GetFileName(resourcePath));
                File.WriteAllBytes(tempFontPath, buffer);
                Font dynamicFont = new Font();
                if (!dynamicFont)
                {
                    Debug.LogError("Failed to create dynamic Font object.");
                    return null;
                }
                dynamicFont = new Font(tempFontPath);
                if (dynamicFont == null)
                {
                    Debug.LogError("Failed to load font from temp file: " + tempFontPath);
                    return null;
                }
                TMP_FontAsset tmpFont = TMP_FontAsset.CreateFontAsset(dynamicFont);
                if (tmpFont == null)
                {
                    Debug.LogError("Failed to create TMP_FontAsset.");
                    return null;
                }
                return tmpFont;
            }
        }

        private static string GetPlatform(VRRig rig)
        {
            string concatStringOfCosmeticsAllowed = rig.concatStringOfCosmeticsAllowed;
            string result;
            if (concatStringOfCosmeticsAllowed.Contains("S. FIRST LOGIN"))
            {
                result = "STEAM";
            }
            else
            {
                if (concatStringOfCosmeticsAllowed.Contains("FIRST LOGIN") ||
                    rig.Creator.GetPlayerRef().CustomProperties.Count >= 2)
                {
                    result = "PC";
                }
                else
                {
                    result = "STANDALONE";
                }
            }
            return result;
        }


        private static AssetBundle LoadAssetBundle(string path)
        {
            Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(path);
            AssetBundle result = AssetBundle.LoadFromStream(manifestResourceStream);
            manifestResourceStream.Close();
            return result;
        }

        // Token: 0x06000007 RID: 7 RVA: 0x00002450 File Offset: 0x00000650
        public static GameObject LoadFromBundle(string path, string GameObjectName)
        {
            return LoadAssetBundle(path).LoadAsset<GameObject>(GameObjectName);
        }

        public GorillaData GetGorillaByNetPlayer(NetPlayer player)
        {
            foreach (KeyValuePair<string, GorillaData> keyValuePair in this._gorillaDataDict)
            {
                if (keyValuePair.Value.UserId == player.UserId)
                {
                    return keyValuePair.Value;
                }
            }
            return null;
        }

        GorillaTagManager gtm;

        private void UpdateGorillaData()
        {
            List<GorillaData> list2 = new List<GorillaData>();
            if (this.gtm != null && PhotonNetwork.InRoom && this.gtm.GameModeName() == "INFECTION")
            {
                foreach (NetPlayer player in this.gtm.currentInfected)
                {
                    try
                    {
                        list2.Add(this.GetGorillaByNetPlayer(player));
                    }
                    catch
                    {
                    }
                }
            }
            List<string> list3 = new List<string>();
            foreach (NetPlayer netPlayer in GorillaParent.instance.vrrigDict.Keys)
            {
                list3.Add(netPlayer.UserId);
            }
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                string str = (vrrig.setMatIndex == 0) ? ColorUtility.ToHtmlStringRGBA(vrrig.materialsToChangeTo[0].color) : "8C1A00";
                Color color;
                Color color2;
                if (ColorUtility.TryParseHtmlString("#" + str, out color))
                {
                    color2 = color;
                }
                else
                {
                    color2 = Color.white;
                }
                if (vrrig.OwningNetPlayer != null)
                {
                    if (!this._gorillaDataDict.Keys.Contains(vrrig.OwningNetPlayer.UserId))
                    {
                        this._gorillaDataDict.Add(vrrig.OwningNetPlayer.UserId, new GorillaData
                        {
                            Color = color2,
                            UserName = vrrig.OwningNetPlayer.NickName,
                            UserId = vrrig.OwningNetPlayer.UserId,
                            BodyTransform = vrrig.transform,
                            HeadTransform = vrrig.headMesh.transform
                        });
                    }
                    else
                    {
                        GorillaData gorillaData3 = this._gorillaDataDict[vrrig.OwningNetPlayer.UserId];
                        gorillaData3.Color = color2;
                        gorillaData3.UserName = vrrig.OwningNetPlayer.NickName;
                        gorillaData3.UserId = vrrig.OwningNetPlayer.UserId;
                        gorillaData3.BodyTransform = vrrig.transform;
                        gorillaData3.HeadTransform = vrrig.headMesh.transform;
                        this._gorillaDataDict[vrrig.OwningNetPlayer.UserId] = gorillaData3;
                        gorillaData3.Infected = (this.gtm != null && PhotonNetwork.InRoom && this.gtm.GameModeName() == "INFECTION" && list2.Contains(gorillaData3));
                    }
                }
            }
            List<GorillaData> list4 = new List<GorillaData>();
            foreach (GorillaData gorillaData4 in this._gorillaDataDict.Values)
            {
                if (!list3.Contains(gorillaData4.UserId))
                {
                    list4.Add(gorillaData4);
                    Debug.Log(gorillaData4.UserName + " is invalid, removing");
                }
            }
            foreach (GorillaData gorillaData5 in list4)
            {
                this._gorillaDataDict.Remove(gorillaData5.UserId);
            }
            this._gorillaDataList = this._gorillaDataDict.Values.ToList<GorillaData>();
        }

        void Update()
        {
            plrs = GorillaParent.instance.vrrigs.ToArray();
            PhotonNetworkController.Instance.disableAFKKick = true;
            GetDistToFected(ref taggingdistance);
            if (Keyboard.current.enterKey.wasPressedThisFrame) showgui = !showgui;
            CastingCamera.fieldOfView = fov;
            CastingCamera.nearClipPlane = 0.01f;
            NoSmoothRigs();
            CameraUpdate();
            UpdateCyclePlayers();
            UpdateGorillaData();
            if (nametags)
                ShowNameTags();
            if (miconoroff)
            {
                setMic("ALL CHAT");
            }
            else
            {
                setMic("PUSH TO TALK");
            }

            if (Keyboard.current.tKey.wasPressedThisFrame) miconoroff = !miconoroff;
            CheckLockedCursor();
        }


        private Dictionary<string, GameObject> _nameTagDict = new Dictionary<string, GameObject>();
        private List<GorillaData> _gorillaDataList = new List<GorillaData>();

        private bool IsSteamPlayer(VRRig rig)
        {
            if (rig == null) return false;

            if (rig.concatStringOfCosmeticsAllowed.Contains("FIRST LOGIN"))
                return true;

            if (rig.playerText1 != null && rig.playerText1.text.Contains("[Steam]"))
                return true;

            var components = rig.GetComponents<MonoBehaviour>();
            foreach (var comp in components)
            {
                if (comp.GetType().Name.Contains("Steam") ||
                    comp.GetType().Name.Contains("PC"))
                    return true;
            }

            return false;
        }

        private void ClearNameTags()
        {
            foreach (KeyValuePair<string, GameObject> keyValuePair in this._nameTagDict)
            {
                UnityEngine.Object.Destroy(keyValuePair.Value);
            }
            this._nameTagDict.Clear();
        }

        private Dictionary<string, GorillaData> _gorillaDataDict = new Dictionary<string, GorillaData>();
        private string _currentFont = "default";

        private float _nameTagScale = 0.6f;

        private float _nameTagPosition = 0.5f;
        private void CreateNameTag(GorillaData gorilla)
        {
            GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(this._nameTag);
            GameObject gameObject2 = gameObject.transform.Find("NameTagTMP").gameObject;
            gameObject.transform.localScale *= 0.065f * this._nameTagScale;
            Transform bodyTransform = gorilla.BodyTransform;
            Vector3 position = bodyTransform.position;
            gameObject.transform.position = new Vector3(position.x, position.y + this._nameTagPosition, position.z);
            gameObject.transform.parent = bodyTransform;
            gameObject2.GetComponent<MeshRenderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            this._nameTagDict.Add(gorilla.UserId, gameObject);
            gameObject.SetActive(false);
        }

        private void ShowNameTags()
        {
            if (this._nameTagDict.Count > this._gorillaDataList.Count)
            {
                this.ClearNameTags();
            }
            foreach (GorillaData gorillaData in this._gorillaDataList)
            {
                if (!this._nameTagDict.ContainsKey(gorillaData.UserId))
                {
                    this.CreateNameTag(gorillaData);
                }
                else
                {
                    foreach (KeyValuePair<string, GameObject> keyValuePair in this._nameTagDict)
                    {
                        if (keyValuePair.Key == gorillaData.UserId)
                        {
                            this.UpdateNameTag(this._gorillaDataDict[keyValuePair.Key], keyValuePair.Value);
                        }
                    }
                }
            }
        }

        private void UpdateNameTag(GorillaData gorilla, GameObject nameTagPlate)
        {
            nameTagPlate.SetActive(true);
            TextMeshPro component = nameTagPlate.transform.Find("NameTagTMP").GetComponent<TextMeshPro>();
            component.text = fpsnametags ? Traverse.Create(gorilla).Field("fps").GetValue().ToString() + " FPS\n" + gorilla.UserName : gorilla.UserName;
            component.color = gorilla.Color;

            if (_currentFont == "default")
                component.font = _defaultFontAsset;
            else if (_currentFont == "gtag")
                component.font = _gtagFontAsset;
            else if (_currentFont == "pixel")
                component.font = _pixelFontAsset;
            else if (_currentFont == "gotham")
                component.font = _gothamFontAsset;
            else if (_currentFont == "designer")
                component.font = _designerFontAsset;
            else if (_currentFont == "ruggedride")
                component.font = _RuggedRide;
            else if (_currentFont == "rushdriver")
                component.font = _RushDriver;
            else if (_currentFont == "amatuer")
                component.font = _Amatuer;

            nameTagPlate.transform.LookAt(CastingCamera.transform.position);
        }


        void CheckLockedCursor()
        {
            if (showgui)
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                return;
            }
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        void SpoofFPS(VRRig plr)
        {
            spoofedfps = Traverse.Create(plr).Field("fps").GetValue().ToString() + " FPS";
            return;
        }

        private float _lastUpdateTime = 0f; 
        private const float _updateInterval = 1f;

        void DrawLeaderboard()
        {

            if (!leaderboard) return;

            // Clear if not in room
            if (!PhotonNetwork.InRoom)
            {
                ClearAllCards();
                return;
            }

            // Update player cards
            SyncPlayerCardsWithRoom();

            // Position cards
            PositionLeaderboardCards();
        }

        void ClearAllCards()
        {
            foreach (var card in _playerCards.Values)
            {
                if (card != null) Destroy(card);
            }
            _playerCards.Clear();
        }

        void SyncPlayerCardsWithRoom()
        {
            var activePlayerIds = new HashSet<string>(PhotonNetwork.PlayerList.Select(p => p.UserId));

            // Remove cards for players who left
            var playersToRemove = _playerCards.Keys
                .Where(id => !activePlayerIds.Contains(id))
                .ToList();

            foreach (var playerId in playersToRemove)
            {
                if (_playerCards.TryGetValue(playerId, out var card) && card != null)
                {
                    Destroy(card);
                }
                _playerCards.Remove(playerId);
            }
        }

        void PositionLeaderboardCards()
        {
            float yOffset = 0f;
            int displayCount = Mathf.Min(10, _gorillaDataList.Count);
            int startIndex = Mathf.Max(0, _gorillaDataList.Count - displayCount);

            var activePlayerIds = new HashSet<string>(PhotonNetwork.PlayerList.Select(p => p.UserId));

            for (int i = startIndex; i < _gorillaDataList.Count; i++)
            {
                GorillaData gorillaData = _gorillaDataList[i];

                if (!activePlayerIds.Contains(gorillaData.UserId))
                    continue;

                // Get or create card
                if (!_playerCards.TryGetValue(gorillaData.UserId, out var card) || card == null)
                {
                    card = Instantiate(_playerCardObject, _leaderboardCanvasObj.transform);
                    _playerCards[gorillaData.UserId] = card;
                }

                // Position card
                float yPos = Screen.height - 120f - (yOffset * 40f);
                card.transform.position = new Vector2(170f, yPos);
                card.transform.localScale = Vector2.one * 1.7f;

                // Update card content
                SetPlayerCardProperties(card, gorillaData, i, _gorillaDataList.Count);
                yOffset++;
            }
        }
        private void SetPlayerCardProperties(GameObject playerCard, GorillaData gorilla, int index, int playerCount)
        {
            if (playerCard == null || gorilla == null)
            {
                return;
            }
            float x = 170f;
            float y = (float)((double)(playerCount - index) * 36.0 - 120.0);
            playerCard.transform.position = new Vector2(x, y);
            playerCard.transform.localScale = Vector2.one * 1.7f;
            Graphic component = playerCard.transform.Find("Behind").Find("Image").GetComponent<Image>();
            Color color;
            ColorUtility.TryParseHtmlString("#8C1A00", out color);
            color = ((color == default(Color)) ? Color.white : color);
            Color color2 = gorilla.Infected ? color : gorilla.Color;
            component.color = color2;
            Transform transform = playerCard.transform.Find("PlayerNumberText");
            TMP_Text tmp_Text = (transform != null) ? transform.GetComponent<TMP_Text>() : null;
            tmp_Text.text = string.Format("{0}", index);
            tmp_Text.font = this._defaultFontAsset;
            Transform transform2 = playerCard.transform.Find("PlayerNameText");
            TMP_Text tmp_Text2 = (transform2 != null) ? transform2.GetComponent<TMP_Text>() : null;
            tmp_Text2.text = !fpsleaderboard ? gorilla.UserName : gorilla.UserName + "     " + Traverse.Create(gorilla).Field("fps").GetValue().ToString() + " FPS";
            tmp_Text2.font = this._defaultFontAsset;
        }

        Dictionary<string, GameObject> _playerCards = new Dictionary<string, GameObject>();
        void StartCamListener()
        {
            this.cameraListener = this.CastingCamera.gameObject.AddComponent<AudioListener>();
            this.cameraListener.enabled = true;
        }

        public void setMic(string val)
        {
            GameObject.Find("GorillaComputer").GetComponent<GorillaComputer>().pttType = val;
        }


        private Texture2D MakeTex(int width, int height, Color col)
        {
            Color[] pix = new Color[width * height];
            for (int i = 0; i < pix.Length; i++)
            {
                pix[i] = col;
            }
            Texture2D result = new Texture2D(width, height);
            result.SetPixels(pix);
            result.Apply();
            return result;
        }

        public Texture2D LoadTexture(string textureName, Vector2Int dimensionsizes)
        {
            Texture2D texture2D = new Texture2D(dimensionsizes.x, dimensionsizes.y, TextureFormat.RGBA32, false);
            Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("GUISTYLETEMP." + textureName);
            if (manifestResourceStream == null) return texture2D;

            byte[] data;
            using (BinaryReader binaryReader = new BinaryReader(manifestResourceStream))
            {
                data = binaryReader.ReadBytes((int)manifestResourceStream.Length);
            }
            ImageConversion.LoadImage(texture2D, data, true); 
            return texture2D;
        }

        void UpdateCyclePlayers()
        {
            if (!PhotonNetwork.InRoom)
            {
                CastedPlayer = GorillaTagger.Instance.offlineVRRig;
                return;
            }
            var otherPlayers = PhotonNetwork.PlayerListOthers;

            if (Keyboard.current.digit1Key.wasPressedThisFrame)
            {
                CastedPlayer = this.plrs[1];
                SpecPlayer(1);
            }
            if (Keyboard.current.digit2Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[2];
                SpecPlayer(2);
            }
            if (Keyboard.current.digit3Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[3];
                SpecPlayer(3);
            }
            if (Keyboard.current.digit4Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[4];
                SpecPlayer(4);
            }
            if (Keyboard.current.digit5Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[5];
                SpecPlayer(5);
            }
            if (Keyboard.current.digit6Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[6];
                SpecPlayer(6);
            }
            if (Keyboard.current.digit7Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[7];
                SpecPlayer(7);
            }
            if (Keyboard.current.digit8Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[8];
                SpecPlayer(8);
            }
            if (Keyboard.current.digit9Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[9];
                SpecPlayer(9);
            }
            if (Keyboard.current.digit0Key.wasPressedThisFrame)
            {
                this.CastedPlayer = this.plrs[0];
                SpecPlayer(0);
            }
        }

        public void SpecPlayer(int plr)
        {
            this._currentSpecGorilla = this._gorillaDataList[plr];
        }

        void PredGuess(VRRig plr)
        {
            float fps = Traverse.Create(plr).Field("fps").GetValue<float>();

            if (fps > 100f)
            {
                preds = UnityEngine.Random.Range(23, 37); 
            }
            else if (fps > 72f)
            {  
                preds = UnityEngine.Random.Range(37, 40);  
            }
            else if (fps > 60f)
            {  
                preds = UnityEngine.Random.Range(41, 55); 
            }
            else
            { 
                preds = UnityEngine.Random.Range(58, 100); 
            }
        }
        private float _transformCooldown;
        private Vector3 _targetPosition;
        private Quaternion _targetRotation;
        private Vector3 _finalPosition;
        private Quaternion _finalRotation;


        void CameraUpdate()
        {

            if (CameraParent == "Head")
            {
                FollowHeadRotation();
            }
            else
            if (CameraParent == "Body")
            {
                FollowBodyRotation();
            }
            else
            if (CameraParent == "Eyes")
                FollowEyes();

        }

        float updtime = 0.0025f;
        float delay = .0025f;

        void FollowHeadRotation()
        {
            if (Time.time >= updtime)
            {
                updtime = Time.time + delay;
                Transform transform = (this.CastedPlayer != null) ? this.CastedPlayer.headMesh.transform : GTPlayer.Instance.headCollider.transform;
                this.cameraOffset = transform.forward * -this.camoffsetz + transform.up * this.camoffsety + transform.right * this.camoffsetx;
                Vector3 b = transform.position + this.cameraOffset;
                Vector3 a = transform.position + transform.up * 0.2f;
                Quaternion b2 = Quaternion.LookRotation(a - b);
                float t = this.smoothening * this.camspeed * Time.deltaTime;
                this.CastingCamera.transform.position = Vector3.Lerp(this.CastingCamera.transform.position, b, t);
                this.CastingCamera.transform.rotation = Quaternion.Lerp(this.CastingCamera.transform.rotation, b2, t);
            }
        }

        Vector3 cameraOffset;
        float camspeed = 10f;

        void FollowBodyRotation()
        {
            if (Time.time >= updtime)
            {
                updtime = Time.time + delay;
                Transform transform = (this.CastedPlayer != null) ? this.CastedPlayer.transform : GTPlayer.Instance.transform;
                this.cameraOffset = transform.forward * -this.camoffsetz + transform.up * this.camoffsety + transform.right * this.camoffsetx;
                Vector3 b = transform.position + this.cameraOffset;
                Vector3 a = transform.position + transform.up * 0.2f;
                Quaternion b2 = Quaternion.LookRotation(a - b);
                float t = this.smoothening * this.camspeed * Time.deltaTime;
                this.CastingCamera.transform.position = Vector3.Lerp(this.CastingCamera.transform.position, b, t);
                this.CastingCamera.transform.rotation = Quaternion.Lerp(this.CastingCamera.transform.rotation, b2, t);
            }
        }

        void FollowEyes()
        {
            if (Time.time >= updtime)
            {
                updtime = Time.time + delay;
                CastingCamera.transform.position = CastedPlayer.headMesh.transform.position + CastedPlayer.headMesh.transform.up * 0.11f + CastedPlayer.headMesh.transform.forward * 0.1f;
                CastingCamera.transform.rotation = CastedPlayer.headMesh.transform.rotation;
            }
        }

        private float lerpTimer = 0f;
        private float switchInterval = .2f;
        private bool lerpHigh = false;
        float antilerp = 0.1f, antitp = 0.2f;
        void NoSmoothRigs()
        {
            lerpTimer += Time.deltaTime;
            if (lerpTimer >= switchInterval)
            {
                lerpHigh = !lerpHigh; 
                lerpTimer = 0f;
            }

            foreach (VRRig r in GorillaParent.instance.vrrigs)
            {
                if (r == GorillaTagger.Instance.offlineVRRig)
                    continue;

                if (CameraParent == "Eyes")
                {
                    r.lerpValueBody = 0.16f;
                    r.lerpValueFingers = 0.16f;
                }
                else
                {
                    if (lerpHigh)
                    {
                        r.lerpValueBody = lerp + antilerp;
                        r.lerpValueFingers = lerp;
                    }
                    else
                    {
                        r.lerpValueBody = lerp;
                        r.lerpValueFingers = lerp - antitp;
                    }
                }
            }
        }
        float lerp = 0.24f;

        private Texture2D CreateEnhancedRoundedTexture(int width, int height, int radius, Color baseColor, Color borderColor, int borderWidth)
        {
            Texture2D texture = new Texture2D(width, height, TextureFormat.ARGB32, false);

            Color[] pixels = new Color[width * height];
            for (int i = 0; i < pixels.Length; i++)
            {
                pixels[i] = Color.clear;
            }

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (IsInRoundedRectangle(x, y, width, height, radius))
                    {
                        if (x < borderWidth || x >= width - borderWidth ||
                            y < borderWidth || y >= height - borderWidth ||
                            !IsInRoundedRectangle(x, y, width, height, radius - borderWidth))
                        {
                            pixels[y * width + x] = borderColor;
                        }
                        else
                        {
                            float xLerp = (float)x / width;
                            float yLerp = (float)y / height;
                            Color gradientColor = Color.Lerp(
                                new Color(baseColor.r * 0.8f, baseColor.g * 0.8f, baseColor.b * 0.8f, baseColor.a),
                                baseColor,
                                (xLerp + yLerp) / 2);

                            pixels[y * width + x] = gradientColor;
                        }
                    }
                }
            }

            texture.SetPixels(pixels);
            texture.Apply();
            return texture;
        }

        private Texture2D CreateDividerTexture(int width, int height)
        {
            Texture2D tex = new Texture2D(width, height);
            Color[] pixels = new Color[width * height];

            for (int x = 0; x < width; x++)
            {
                float t = (float)x / width;
                Color col = Color.Lerp(
                    new Color(0.7f, 0.7f, 0.7f, 0.8f),
                    new Color(0.7f, 0.7f, 0.7f, 0.8f),
                    t);

                for (int y = 0; y < height; y++)
                {
                    pixels[y * width + x] = col;
                }
            }

            tex.SetPixels(pixels);
            tex.Apply();
            return tex;
        }

        bool IsInRoundedRectangle(int x, int y, int w, int h, int r)
        {
            int cx = x;
            int cy = y;

            if (x >= r && x < w - r && y >= r && y < h - r)
                return true;

            if (x < r && y < r)
            {
                float dx = r - x;
                float dy = r - y;
                return (dx * dx + dy * dy) <= (r * r);
            }

            if (x >= w - r && y < r)
            {
                float dx = x - (w - r);
                float dy = r - y;
                return (dx * dx + dy * dy) <= (r * r);
            }

            if (x < r && y >= h - r)
            {
                float dx = r - x;
                float dy = y - (h - r);
                return (dx * dx + dy * dy) <= (r * r);
            }

            if (x >= w - r && y >= h - r)
            {
                float dx = x - (w - r);
                float dy = y - (h - r);
                return (dx * dx + dy * dy) <= (r * r);
            }

            return true;
        }

        public static void ChangeName(string PlayerName)
        {
            GorillaComputer.instance.currentName = PlayerName;
            PhotonNetwork.LocalPlayer.NickName = PlayerName;
            GorillaComputer.instance.savedName = PlayerName;
            PlayerPrefs.SetString("playerName", PlayerName);
            PlayerPrefs.Save();
        }

        public static void ChangeColor(Color color)
        {
            PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
            PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
            PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));
            GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
            PlayerPrefs.Save();
        }

        void InitializeScoreboard()
        {
            scoreheadertexture = CreateEnhancedRoundedTexture(300, 250, 15,
                new Color(0.1f, 0.1f, 0.1f, 0.65f), 
                new Color(0.1f, 0.1f, 0.1f, 0.6f),    
                2);     
        }


        void DrawDivider(float x, float y, float width)
        {
            Texture2D dividerTex = CreateDividerTexture((int)width, 3);
            GUI.Box(new Rect(x, y, width, 3), GUIContent.none, new GUIStyle() { normal = { background = dividerTex } });
        }

        void RoomJoiner(int i)
        {
            GUILayout.BeginVertical();
            roomjoinertext = GUILayout.TextField(roomjoinertext, 12);
            GUILayout.Label("Room To Join");
            if (PhotonNetwork.InRoom || PhotonNetwork.InLobby)
            {
                GUILayout.Button("Leave");
            }
            else
            {
                GUILayout.Button("Join");
            }
            GUILayout.EndVertical();
        }

        private void ToggleDistanceCard()
        {
            this._showDistanceCard = !this._showDistanceCard;
            if (this._showDistanceCard)
            {
                return;
            }
            UnityEngine.Object.Destroy(this._playerDistanceCard);
        }


        Rect nametagswindow = new Rect(200f, 600f, 150f, 250f);
        Rect keybindswindow = new Rect(900f, 20f, 150f, 500f);
        bool keybindwindow = false;
        Rect tagmanagerwindow = new Rect(1500f, 500f, 200f, 245f);

        private void OnGUI()
        {
            if (taggerdistance) DrawDistanceCard();
            DrawLeaderboard();

            GUIStyle transparentStyle = new GUIStyle { normal = { background = Texture2D.blackTexture } };

            Texture2D currentMicTexture = miconoroff ? mic_on : mic_off;
            if (currentMicTexture != null)
            {
                GUI.color = new Color(1, 1, 1, 0.8f);
                GUI.DrawTexture(new Rect(1800, 900, 100, 150), currentMicTexture, ScaleMode.ScaleToFit, true);
                GUI.color = Color.white;
            }

            if (!showgui) return;

            if (showCamSettings) camSettingsRect = GUI.Window(1, camSettingsRect, Settings, "Camera Settings", GUI.skin.box);
            if (showOtherGUIs) otherGUIsRect = GUI.Window(2, otherGUIsRect, OtherGUIsWindow, "Other GUIs", GUI.skin.box);
            if (showMiscMods) miscModsRect = GUI.Window(3, miscModsRect, MiscModsWindow, "Misc Mods", GUI.skin.box);
            if (showModCheckers) modCheckersRect = GUI.Window(4, modCheckersRect, ModCheckersWindow, "Mod Checkers", GUI.skin.box);
            if (roomjoiner) roomJoiner = GUI.Window(7, roomJoiner, RoomJoiner, "", GUI.skin.box);
            if (nametags) nametagswindow = GUI.Window(8, nametagswindow, DrawNameTagMenu, "NameTag Options", GUI.skin.box);
            if (keybindwindow) keybindswindow = GUI.Window(9, keybindswindow, Keybinds, "KeyBinds", GUI.skin.box);
            if (tagmanager) tagmanagerwindow = GUI.Window(10, tagmanagerwindow, TagManager, "Tag Manager", GUI.skin.box);

            var customSkin = new GUIStyle();
            GUIStyle window = new GUIStyle(GUI.skin.window) { fontSize = 16, fontStyle = FontStyle.Bold, alignment = TextAnchor.UpperCenter };
            GUIStyle button = new GUIStyle(GUI.skin.button) { fontSize = 14, fixedHeight = 30f, margin = new RectOffset(5, 5, 5, 5) };
            GUIStyle label = new GUIStyle(GUI.skin.label) { fontSize = 14, alignment = TextAnchor.MiddleLeft };
            GUIStyle horizontalSlider = new GUIStyle(GUI.skin.horizontalSlider);
            GUIStyle horizontalSliderThumb = new GUIStyle(GUI.skin.horizontalSliderThumb) { fixedHeight = 20f, fixedWidth = 10f };

            Rect mainRect = new Rect(20f, 30f, 150f, 350f);
            mainRect = GUI.Window(5, mainRect, MainWindow, "Quutrs Casting Mod", GUI.skin.box);
        }

        void Keybinds(int i)
        {
            GUILayout.BeginVertical();
            GUILayout.Space(15f);
            if (!this._isToggleMenuKeybindInProgress)
            {
                GUILayout.Label("Toggle Menu Keybind:");
                this.DrawKeyButton("Toggle Menu", ref this._toggleMenuKey, ref this._isToggleMenuKeybindInProgress);
            }
            else
            {
                GUILayout.Label("Press any key to set as Keybinding:");
                if (Event.current.isKey)
                {
                    this._toggleMenuKey = (Key)Enum.Parse(typeof(Key), Event.current.keyCode.ToString());
                    this._isToggleMenuKeybindInProgress = false;
                }
            }
            GUILayout.EndVertical();

            GUI.DragWindow(new Rect(0, 0, 10000, 20));
        }
        Key _toggleMenuKey;
        private void DrawKeyBindButton(string label, ref bool isInProgress, ref Key key, float buttonSpacing, float buttonWidth, Vector2 keyMenuPosition)
        {
            if (!isInProgress)
            {
                GUILayout.Label(label + " Keybind:");
                this.DrawKeyButton(label, ref key, ref isInProgress);
            }
        }

        private void DrawKeyButton(string buttonText, ref Key key, ref bool isKeybindInProgress)
        {
            if (!GUILayout.Button(string.Format("{0}: {1}", buttonText, key)))
            {
                return;
            }
            isKeybindInProgress = true;
        }


        void MainWindow(int id)
        {
            GUILayout.BeginVertical();
            GUILayout.Space(15f);

            showCamSettings = GUILayout.Toggle(showCamSettings, "Camera Settings", "Button", GUILayout.Height(30));
            showOtherGUIs = GUILayout.Toggle(showOtherGUIs, "Other GUIs", "Button", GUILayout.Height(30));
            showMiscMods = GUILayout.Toggle(showMiscMods, "Misc Mods", "Button", GUILayout.Height(30));
            showModCheckers = GUILayout.Toggle(showModCheckers, "Mod Checkers", "Button", GUILayout.Height(30));
            keybindwindow = GUILayout.Toggle(keybindwindow, "KeyBinds", "Button", GUILayout.Height(30));

            if (GUILayout.Button("Close GUI [Enter]", GUILayout.Height(25)))
            {
                showgui = false;
            }
            if (GUILayout.Button("Save Settings", GUILayout.Height(25)))
            {
                SaveSettings();
            }
            if (GUILayout.Button("Load Settings", GUILayout.Height(25)))
            {
                LoadSettings();
            }

            GUILayout.EndVertical();

            GUI.DragWindow(new Rect(0, 0, 10000, 20));
        }

        void TagPlayer(Player plr)
        {
            GorillaGameManager.instance.gameObject.GetComponent<GorillaTagManager>().currentInfected.Add(plr);
        }

        bool killFeedEnabled;
        float _apCooldown;
        float _apCooldownInterval;
        private string settingsFilePath;
        bool scoreboard = true;
        private bool _isToggleMenuKeybindInProgress;

        private void SaveSettings()
        {
            SettingsSaveData settingsSaveData = new SettingsSaveData
            {
                _fov = this.fov,
                _moveSpeed = this.camspeed,
                _movementMultiplier = this.smoothening,
                _trackPosForward = this.camoffsetz,
                _trackPosRight = this.camoffsetx,
                _trackPosUp = this.camoffsety,
                _showUiManager = this.showgui,
                showLeaderboard = this.leaderboard,
                killFeedEnabled = this.killFeedEnabled,
                _autoPilot = this._autoPilot,
                _apCooldown = this._apCooldown,
                _apCooldownInterval = this._apCooldownInterval,
                _showDistanceCard = this._showDistanceCard,
                showNameTags = this.nametags,
                _currentFont = this._currentFont,
                _nameTagScale = this._nameTagScale,
                _nameTagPosition = this._nameTagPosition,
            };

            string contents = JsonConvert.SerializeObject(settingsSaveData);
            File.WriteAllText(settingsFilePath, contents);

            Debug.Log("Settings saved successfully!");
        }

        private void LoadSettings()
        {
            if (File.Exists(settingsFilePath))
            {
                string json = File.ReadAllText(settingsFilePath);
                SettingsSaveData settingsSaveData = JsonConvert.DeserializeObject<SettingsSaveData>(json);

                this.fov = settingsSaveData._fov;
                this.camspeed = settingsSaveData._moveSpeed;
                this.smoothening = settingsSaveData._movementMultiplier;
                this.camoffsetz = settingsSaveData._trackPosForward;
                this.camoffsetx = settingsSaveData._trackPosRight;
                this.camoffsety = settingsSaveData._trackPosUp;
                this.showgui = settingsSaveData._showUiManager;
                this.leaderboard = settingsSaveData.showLeaderboard;
                this.killFeedEnabled = settingsSaveData.killFeedEnabled;
                this._autoPilot = settingsSaveData._autoPilot;
                this._apCooldown = settingsSaveData._apCooldown;
                this._apCooldownInterval = settingsSaveData._apCooldownInterval;
                this._showDistanceCard = settingsSaveData._showDistanceCard;
                this.nametags = settingsSaveData.showNameTags;
                this._currentFont = settingsSaveData._currentFont;
                this._nameTagScale = settingsSaveData._nameTagScale;
                this._nameTagPosition = settingsSaveData._nameTagPosition;

                Debug.Log("Settings loaded successfully!");
            }
            else
            {
                Debug.LogWarning("Settings file not found, using default settings.");
                SetDefaultSettings();
            }
        }

        private void SwitchFont()
        {
            string currentFont = this._currentFont;
            string nextFont;

            if (currentFont == "default")
                nextFont = "gtag";
            else if (currentFont == "gtag")
                nextFont = "pixel";
            else if (currentFont == "pixel")
                nextFont = "gotham";
            else if (currentFont == "gotham")
                nextFont = "designer";
            else if (currentFont == "designer")
                nextFont = "ruggedride";
            else if (currentFont == "ruggedride")
                nextFont = "rushdriver";
            else if (currentFont == "rushdriver")
                nextFont = "amatuer";
            else 
                nextFont = "default";

            this._currentFont = nextFont;
        }


        private void DrawNameTagMenu(int windowID)
        {
            GUILayout.Space(17f);

            if (GUILayout.Button($"Font: {this._currentFont}", GUILayout.Width(130f), GUILayout.Height(20f)))
            {
                this.SwitchFont();
            }

            if (GUILayout.Button("FPS Checker", GUILayout.Width(130f), GUILayout.Height(20f)))
            {
                fpsnametags = !fpsnametags;
            }

            if (GUILayout.Button("Platform Checker", GUILayout.Width(130f), GUILayout.Height(20f)))
            {
                fpsnametags = !fpsnametags;
            }

            GUILayout.Space(10f);

            GUILayout.Label($"Scale: {Math.Round(this._nameTagScale, 1)}");
            this._nameTagScale = GUILayout.HorizontalSlider(this._nameTagScale, 0.1f, 2f, GUILayout.Width(130f));

            GUILayout.Space(10f);

            GUILayout.Label($"Position: {Math.Round(this._nameTagPosition, 1)}");
            this._nameTagPosition = GUILayout.HorizontalSlider(this._nameTagPosition, 0.1f, 3f, GUILayout.Width(130f));

            GUILayout.Space(15f);

            if (GUILayout.Button("Apply", GUILayout.Width(130f), GUILayout.Height(20f)))
            {
                this.ClearNameTags();
            }

            GUI.DragWindow(new Rect(0f, 0f, 10000f, 20f));
        }

        bool tagmanager = false;
        private AudioListener cameraListener;

        void OtherGUIsWindow(int id)
        {
            GUILayout.BeginVertical();

            if (GUILayout.Button("Leader Board")) leaderboard = !leaderboard;
            if (GUILayout.Button("Tag Manager")) tagmanager = !tagmanager;

            if (GUILayout.Button("Score Board")) scoreboardon = !scoreboardon;
            GUILayout.Button("Mini Map");
            GUILayout.Button("Score Board");
            if (GUILayout.Button("Tagger Distance")) taggerdistance = !taggerdistance;

            GUILayout.EndVertical();
            GUI.DragWindow(new Rect(0, 0, 10000, 20));
        }

        void MiscModsWindow(int id)
        {
            GUILayout.BeginVertical();

            if (GUILayout.Button("NameTags")) nametags = !nametags;
            GUILayout.Button("Lava Distance Above Head");
            GUILayout.Button("Change Name");
            GUILayout.Button("Change Color");
            GUILayout.Button("Join Room");
            GUILayout.Button("WASD");
            GUILayout.Button("Tag Manager");
            GUILayout.Button("Start Timer From: -10");

            GUILayout.EndVertical();
            GUI.DragWindow(new Rect(0, 0, 10000, 20));
        }

        void ModCheckersWindow(int id)
        {
            GUILayout.BeginVertical();
            if (GUILayout.Button("Show FPS On LeaderBoard")) fpsleaderboard = !fpsleaderboard;
            GUILayout.Button("Show Platform On LeaderBoard");

            GUILayout.EndVertical();
            GUI.DragWindow(new Rect(0, 0, 10000, 20));
        }



        private void SetDefaultSettings()
        {
            this.fov = 100f;
            this.smoothening = 0.5f;
            camspeed = 10f;
            this.camoffsetz = 1.7f;
            this.camoffsetx = 0f;
            this.camoffsety = 0.3f;
            this.showgui = true;
            this.leaderboard = true;
            this.killFeedEnabled = true;
        }

        void Settings(int windowID)
        {
            GUILayout.BeginVertical(GUILayout.ExpandHeight(true));
            GUILayout.Space(20f);
            GUILayout.BeginHorizontal();
            GUILayout.Label("Camera Mode:", GUILayout.Width(120));
            if (GUILayout.Button(CameraParent, GUILayout.ExpandWidth(true)))
            {
                if (CameraParent == "Head") CameraParent = "Body";
                else if (CameraParent == "Body") CameraParent = "Eyes";
                else if (CameraParent == "Eyes") CameraParent = "Head";
            }
            GUILayout.EndHorizontal();
            GUILayout.Space(10f); 
            GUILayout.BeginHorizontal();
            GUILayout.Label($"FOV: {fov:F0}°", GUILayout.Width(120));
            fov = GUILayout.HorizontalSlider(fov, 90f, 135f, GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();
            GUILayout.Space(10f);

            SliderControl("X Position:", ref camoffsetx, -5f, 5f);
            SliderControl("Y Position:", ref camoffsety, -5f, 5f);
            SliderControl("Z Position:", ref camoffsetz, -5f, 5f);
            if (GUILayout.Button("Control Offsets With Wasd")) movewithwasd = !movewithwasd;

            GUILayout.Space(10f);
            SliderControl("Smoothing:", ref smoothening, 0.1f, 5f, "0.00");
            SliderControl("Speed:", ref camspeed, 0f, 5f, "0.00");

            GUILayout.Space(10f);

            SliderControl("Rig Smoothing:", ref lerp, 0f, 0.99f, "0.00");
            SliderControl("Photon Delay:", ref switchInterval, 0f, 0.5f, "0.00");
            SliderControl("Anti Delay Lerp:", ref antilerp, 0f, 0.5f, "0.00");
            SliderControl("Anti  Delayed TPs:", ref antitp, 0f, 0.5f, "0.00");
            SliderControl("Caster Delay:", ref delay, 0f, 0.1f, "0.0000");
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Camera Listener")) cameraListener.enabled = !cameraListener.enabled;
            GUILayout.EndVertical();
            GUI.DragWindow(new Rect(0, 0, 1000, 20));
        }

        void SliderControl(string label, ref float value, float min, float max, string format = "0.0")
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, GUILayout.Width(120));
            value = GUILayout.HorizontalSlider(value, min, max, GUILayout.Width(50));
            GUILayout.Label(value.ToString(format), GUILayout.Width(40));
            GUILayout.EndHorizontal();
        }

    }

    public class SettingsSaveData
    {
        // Token: 0x04000104 RID: 260
        public bool listenerBool = true;

        // Token: 0x04000105 RID: 261
        public float _fov = 90f;

        // Token: 0x04000106 RID: 262
        public float _clippingPlaneNear = 0.01f;

        // Token: 0x04000107 RID: 263
        public bool _showKeybindMenu;

        // Token: 0x04000108 RID: 264
        public bool _showColorMenu;

        // Token: 0x04000109 RID: 265
        public bool _showTimeChangerMenu;

        // Token: 0x0400010A RID: 266
        public bool _showNameChangerMenu;

        // Token: 0x0400010B RID: 267
        public float _zoomFov = 15f;

        // Token: 0x0400010C RID: 268
        public float _moveSpeed = 30f;

        // Token: 0x0400010D RID: 269
        public float _rotationSpeed = 1f;

        // Token: 0x0400010E RID: 270
        public float _rotationMultiplier = 0.1f;

        // Token: 0x0400010F RID: 271
        public float _movementMultiplier = 10f;

        // Token: 0x04000110 RID: 272
        public bool _mouseLook;

        // Token: 0x04000111 RID: 273
        public float _cameraLerp = 0.12f;

        // Token: 0x04000112 RID: 274
        public float _quatLerp = 0.055f;

        // Token: 0x04000113 RID: 275
        public string _specPart = "head";

        // Token: 0x04000114 RID: 276
        public bool _smoothMode = true;

        // Token: 0x04000115 RID: 277
        public float _trackPosForward = 1.75f;

        // Token: 0x04000116 RID: 278
        public float _trackPosRight;

        // Token: 0x04000117 RID: 279
        public float _trackPosUp;

        // Token: 0x04000118 RID: 280
        public bool _showNests;

        // Token: 0x04000119 RID: 281
        public float _minSwitchInterval = 5f;

        // Token: 0x0400011A RID: 282
        public bool _smoothObservation;

        // Token: 0x0400011B RID: 283
        public float _observationLerp = 2f;

        // Token: 0x0400011C RID: 284
        public float _observationSlerp = 3f;

        // Token: 0x0400011D RID: 285
        public float _verticalMoveSpeed = 5f;

        // Token: 0x0400011E RID: 286
        public float _verticalOffset;

        // Token: 0x0400011F RID: 287
        public bool _showUiManager = true;

        // Token: 0x04000120 RID: 288
        public bool showLeaderboard;

        // Token: 0x04000121 RID: 289
        public bool killFeedEnabled;

        // Token: 0x04000122 RID: 290
        public bool _autoPilot;

        // Token: 0x04000123 RID: 291
        public float _apCooldown;

        // Token: 0x04000124 RID: 292
        public float _apCooldownInterval = 4f;

        // Token: 0x04000125 RID: 293
        public bool _showDistanceCard;

        // Token: 0x04000126 RID: 294
        public Key _toggleMenuKey = Key.Tab;

        // Token: 0x04000127 RID: 295
        public Key _zoomKey = Key.Z;

        // Token: 0x04000128 RID: 296
        public Key _switchModeKey = Key.LeftAlt;

        // Token: 0x04000129 RID: 297
        public Key _createNestKey = Key.N;

        // Token: 0x0400012A RID: 298
        public Key _toggleDistanceCardKey = Key.B;

        // Token: 0x0400012B RID: 299
        public Key _toggleLeaderboardKey = Key.L;

        // Token: 0x0400012C RID: 300
        public Key _resetCameraKey = Key.Delete;

        // Token: 0x0400012D RID: 301
        public Key _toggleMicKey = Key.T;

        // Token: 0x0400012E RID: 302
        public Key _specPartKey = Key.H;

        // Token: 0x0400012F RID: 303
        public Key _specSmoothKey = Key.J;

        // Token: 0x04000130 RID: 304
        public bool showNameTags;

        // Token: 0x04000131 RID: 305
        public string _currentFont = "default";

        // Token: 0x04000132 RID: 306
        public float _nameTagScale = 0.6f;

        // Token: 0x04000133 RID: 307
        public float _nameTagPosition = 0.5f;

        // Token: 0x04000134 RID: 308
        public Dictionary<string, SettingsSaveData.MenuInfo> _menuInfoDict = new Dictionary<string, SettingsSaveData.MenuInfo>();

        // Token: 0x04000135 RID: 309
        public bool miniMapEnabled;

        // Token: 0x04000136 RID: 310
        public bool showScoreboard;

        // Token: 0x04000137 RID: 311
        public int currentScoreboard;

        // Token: 0x04000138 RID: 312
        public bool _pauseOnRoundEnd = true;

        // Token: 0x04000139 RID: 313
        public string _team1name = "TTT";

        // Token: 0x0400013A RID: 314
        public string _team2name = "TSO";

        // Token: 0x0400013B RID: 315
        public bool _timerWait = true;

        // Token: 0x0400013C RID: 316
        public bool _countDown;

        // Token: 0x0200001A RID: 26
        public class MenuInfo
        {
            // Token: 0x0400013D RID: 317
            public Vector2 MenuPosition = new Vector2(0f, 0f);

            // Token: 0x0400013E RID: 318
            public string MenuName;
        }
    }
}