﻿using BepInEx;
using GorillaLocomotion;
using HarmonyLib;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.InputSystem;
using UnityEngine.ProBuilder;

[BepInPlugin("com.gtc.gorillatag.scrimcasterv2", "Scrim Caster v2", "2.0.2")]
public class CastingProp : BaseUnityPlugin
{
    public bool followHead { get; set; } = true;
    public bool isSmoothAllowed = true;

    private Camera castingCamera;
    public static VRRig rigToFollow;
    private float cameraOffsetForward = 5f, cameraOffsetRight = 1f, cameraOffsetUp = 2f;
    private float cameraPositionSmoothness = 1f;
    private float cameraRotationSmoothness = 1f;
    private string rigtofollowstext = "";
    private List<VRRig> AllRigs => new List<VRRig>(GorillaParent.instance.vrrigs);
    float fov = 100;
    float playernetworkingdelay = 0f;
    bool nonetworkingdelay = false;
    Vector3 cameraOffset;
    bool showcastedplayerattrib = true;
    bool showLeaderboard = true;
    private GUIStyle leaderboardTextStyle;
    bool fpschecker = true;
    bool steamchecker;
    bool muteplayers;
    float closestlava;
    Texture2D meta, steam;
    void Awake()
    {
        leaderboardTextStyle = new GUIStyle();
        leaderboardTextStyle.fontSize = 16;
        leaderboardTextStyle.fontStyle = FontStyle.Bold;
        leaderboardTextStyle.normal.textColor = Color.white;
        leaderboardTextStyle.alignment = TextAnchor.MiddleLeft;
        leaderboardTextStyle.richText = true;
        meta = LoadText("GUISTYLETEMP.Asset.meta.png");
        steam = LoadText("GUISTYLETEMP.Asset.steam.png");
    }

    Texture2D LoadText(string name)
    {
        var assembly = System.Reflection.Assembly.GetExecutingAssembly();
        using (var stream = assembly.GetManifestResourceStream(name))
        {
            if (stream == null) return null;
            byte[] buffer = new byte[stream.Length];
            stream.Read(buffer, 0, buffer.Length);
            Texture2D texture = new Texture2D(2, 2);
            texture.LoadImage(buffer);
            return texture;
        }
    }

    void OnGUI()
    {
        ShowCastedPlayersAttrib(showcastedplayerattrib);
        if (showLeaderboard) DrawLeaderboard();
    }

    void DrawLeaderboard()
    {
        float cardWidth = 300f;
        float cardHeight = 35f;
        float skewOffset = -20f;
        float startX = 20f;
        float startY = Screen.height - 10f;
        float padding = 5f;

        var sortedRigs = AllRigs;

        for (int i = 0; i < sortedRigs.Count; i++)
        {
            var rig = sortedRigs[i];
            if (rig == null && rig == GorillaTagger.Instance.offlineVRRig) continue;

            float yPos = startY - (cardHeight + padding) * (i + 1);
            DrawPlayerCard(startX, yPos, cardWidth, cardHeight, skewOffset, rig, i);
        }
    }

    void DrawPlayerCard(float x, float y, float width, float height, float skew, VRRig rig, int rank)
    {
        HelperForRect.DrawParallelogram(x, y, width, height, skew, new Color(0f, 0f, 0f, 0.4f));

        float rankWidth = 50f;
        HelperForRect.DrawParallelogram(x, y, rankWidth, height, skew, new Color(0.1f, 0.1f, 0.1f, 0.5f));
        GUI.Label(new Rect(x + 10, y + height / 2 - 10, rankWidth, 20), $"{rank}", leaderboardTextStyle);

        float colorIndicatorSize = 30f;
        float colorX = x + rankWidth + 10;
        HelperForRect.DrawParallelogram(colorX, y + height / 2 - colorIndicatorSize / 2,
                                      colorIndicatorSize, colorIndicatorSize, skew / 2, rig.playerColor);

        float nameX = colorX + colorIndicatorSize + 10;
        string playerName = rig.playerText1 != null ? rig.playerText1.text : "Player";
        GUI.Label(new Rect(nameX, y + height / 2 - 10, width - nameX, 20),
            $"<size=20><b>{playerName}</b></size>", leaderboardTextStyle);
        if (fpschecker)
            GUI.Label(new Rect(nameX + 175, y + height / 2 - 10, width - nameX, 20),
                $"<size=16><b><color=green> {Traverse.Create(rig).Field("fps").GetValue()} </color></b></size>");

        if (rig == rigToFollow)
        { HelperForRect.DrawParallelogramOutline(x, y, width, height, skew, 2f, Color.yellow); }
    }

    void ShowCastedPlayersAttrib(bool ison = true)
    {
        if (!ison || rigToFollow == null) return;

        float width = 550f;
        float height = 180f;
        float skewOffset = -30f;
        float x = Screen.width - width + 30f;
        float y = Screen.height - height - 10f;

        HelperForRect.DrawParallelogram(x, y, width, height, skewOffset, new Color(0f, 0f, 0f, 0.5f));

        GUILayout.BeginArea(new Rect(x, y, width, height));
        {
            GUILayout.BeginVertical();
            GUILayout.Space(10);
            float colorSize = 60f;
            float colorX = 20f;
            float colorY = GUILayoutUtility.GetLastRect().y + 10f;
            GUILayout.BeginHorizontal();
            {
                HelperForRect.DrawParallelogram(colorX, colorY, colorSize, colorSize, skewOffset / 2, rigToFollow.playerColor);

                GUILayout.Space(colorSize + 20);

                GUILayout.Label($"<color=white><size=16><b>Casted Player:</b> {rigtofollowstext}</size></color>");
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(15);
            GUILayout.BeginHorizontal();
            GUILayout.Space(colorSize + 10);
            GUILayout.Label($"<color=white><size=14><b>Player Color:</b> {rigToFollow.playerColor.r * 9} {rigToFollow.playerColor.g * 9} {rigToFollow.playerColor.b * 9}</size></color>");
            GUILayout.EndHorizontal();
            GUILayout.Space(10);
            bool isSteam = rigToFollow.concatStringOfCosmeticsAllowed.Contains("FIRST LOGIN");
            Texture2D platformIcon = isSteam ? steam : meta;
            string platformText = isSteam ? "STEAM" : "QUEST";

            GUILayout.BeginHorizontal();
            GUILayout.Space(colorSize + 10);
            GUILayout.Label($"<color=white><size=14><b>Closest Lava:</b> {Mathf.Round(closestlava)}</size></color>");
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Space(colorSize + 10);
            GUILayout.Label("<color=white><size=14><b>Platform:</b></size></color>");
            GUILayout.Label($"<color=white><size=14> {platformText}</size></color>");
            if (platformIcon != null)
            { GUILayout.Label(platformIcon, GUILayout.Width(20), GUILayout.Height(20)); }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
        }
        GUILayout.EndArea();
    }

    void Start()
    {
        rigToFollow = GorillaTagger.Instance.offlineVRRig;
        if (rigToFollow != null && rigToFollow.playerText1 != null)
        {
            rigtofollowstext = rigToFollow.playerText1.text;
        }
    }

    void Update()
    {
        SpectateAttrib();
        GetDistToFected(ref closestlava);
        if (Keyboard.current.f1Key.wasPressedThisFrame) showcastedplayerattrib = !showcastedplayerattrib;
        if (Keyboard.current.f2Key.wasPressedThisFrame) showLeaderboard = !showLeaderboard;
        if (Keyboard.current.fKey.wasPressedThisFrame & showLeaderboard == true) fpschecker = fpschecker;
    }

    void SpectateAttrib()
    {
        if (Keyboard.current == null) return;

        if (Keyboard.current.digit0Key.wasPressedThisFrame) StartSpecFollowerPlayer(0);
        if (Keyboard.current.digit9Key.wasPressedThisFrame) StartSpecFollowerPlayer(9);
        if (Keyboard.current.digit8Key.wasPressedThisFrame) StartSpecFollowerPlayer(8);
        if (Keyboard.current.digit7Key.wasPressedThisFrame) StartSpecFollowerPlayer(7);
        if (Keyboard.current.digit6Key.wasPressedThisFrame) StartSpecFollowerPlayer(6);
        if (Keyboard.current.digit5Key.wasPressedThisFrame) StartSpecFollowerPlayer(5);
        if (Keyboard.current.digit4Key.wasPressedThisFrame) StartSpecFollowerPlayer(4);
        if (Keyboard.current.digit3Key.wasPressedThisFrame) StartSpecFollowerPlayer(3);
        if (Keyboard.current.digit2Key.wasPressedThisFrame) StartSpecFollowerPlayer(2);
        if (Keyboard.current.digit1Key.wasPressedThisFrame) StartSpecFollowerPlayer(1);
    }

    void StartSpecFollowerPlayer(int i)
    {
        if (AllRigs == null || i < 0 || i >= AllRigs.Count) return;

        rigToFollow = AllRigs[i];
        if (rigToFollow != null && rigToFollow.playerText1 != null)
        {
            rigtofollowstext = rigToFollow.playerText1.text;
        }
    }

    public class PlayerColorData
    {
        public static Color color => CastingProp.rigToFollow != null ? CastingProp.rigToFollow.playerColor : Color.white;

        public static float GetColorR()
        {
            return color.r;
        }

        public static float GetColorG()
        {
            return color.g;
        }

        public static float GetColorB()
        {
            return color.b;
        }

        public static float ColorRed => GetColorR();
        public static float ColorGreen => GetColorG();
        public static float ColorBlue => GetColorB();
    }

    VRRig closestFected;
    private void GetDistToFected(ref float output)
    {
        float num = float.MaxValue;
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            if (vrrig != null && vrrig.mainSkin.material.name.Contains("fected"))
            {
                float num2 = Vector3.Distance(rigToFollow.transform.position, vrrig.transform.position);
                if (num2 < num)
                {
                    num = num2;
                    this.closestFected = vrrig;
                }
            }
        }
        output = num;
    }


    public static class HelperForRect
    {
        private static Material backgroundMaterial;

        private static void CreateBackgroundMaterial()
        {
            if (backgroundMaterial == null)
            {
                Shader shader = Shader.Find("Hidden/Internal-Colored");
                if (shader != null)
                {
                    backgroundMaterial = new Material(shader);
                    backgroundMaterial.hideFlags = HideFlags.HideAndDontSave;
                    backgroundMaterial.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                    backgroundMaterial.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                    backgroundMaterial.SetInt("_Cull", 0);
                    backgroundMaterial.SetInt("_ZWrite", 0);
                }
            }
        }

        public static void DrawParallelogram(float x, float y, float width, float height, float skewOffset, Color color)
        {
            CreateBackgroundMaterial();
            if (backgroundMaterial == null) return;

            backgroundMaterial.SetPass(0);

            GL.PushMatrix();
            GL.LoadPixelMatrix();
            GL.Begin(GL.QUADS);
            GL.Color(color);

            GL.Vertex3(x, y, 0f);
            GL.Vertex3(x + width, y, 0f);
            GL.Vertex3(x + width + skewOffset, y + height, 0f);
            GL.Vertex3(x + skewOffset, y + height, 0f);

            GL.End();
            GL.PopMatrix();
        }

        public static void DrawParallelogramOutline(float x, float y, float width, float height, float skewOffset, float thickness, Color color)
        {
            CreateBackgroundMaterial();
            if (backgroundMaterial == null) return;

            backgroundMaterial.SetPass(0);

            GL.PushMatrix();
            GL.LoadPixelMatrix();
            GL.Begin(GL.LINES);
            GL.Color(color);
            GL.Vertex3(x, y, 0f);
            GL.Vertex3(x + width, y, 0f);

            GL.Vertex3(x + width, y, 0f);
            GL.Vertex3(x + width + skewOffset, y + height, 0f);

            GL.Vertex3(x + width + skewOffset, y + height, 0f);
            GL.Vertex3(x + skewOffset, y + height, 0f);

            GL.Vertex3(x + skewOffset, y + height, 0f);
            GL.Vertex3(x, y, 0f);

            GL.End();
            GL.PopMatrix();
        }
    }
}